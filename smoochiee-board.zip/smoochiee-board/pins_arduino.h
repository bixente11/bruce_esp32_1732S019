#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include "soc/soc_caps.h"
#include <stdint.h>

static const uint8_t TX = 43;
static const uint8_t RX = 44;

static const uint8_t SDA = 47;
static const uint8_t SCL = 48;

// Modified elsewhere
static const uint8_t SS = 21;
static const uint8_t MOSI = 15;
static const uint8_t MISO = 16;
static const uint8_t SCK = 17;

#define SERIAL_RX 2
#define SERIAL_TX 1
#define BAD_RX SERIAL_RX
#define BAD_TX SERIAL_TX
#define USB_as_HID 1

// #define BTN_ALIAS "\"OK\""
// #define HAS_5_BUTTONS
// #define SEL_BTN 0
// #define UP_BTN 41
// #define DW_BTN 40
// #define R_BTN 38
// #define L_BTN 39
// #define BTN_ACT LOW

// Encoder
#define HAS_ENCODER
#define ENCODER_INA 40
#define ENCODER_INB 41
#define ENCODER_KEY 42
#define HAS_BTN 1
#define BTN_ALIAS "\"Mid\""
#define SEL_BTN ENCODER_KEY
#define UP_BTN -1
#define DW_BTN -1
#define BK_BTN 38
#define BTN_ACT LOW

#define RXLED 4
#define LED 5
#define LED_ON HIGH
#define LED_OFF LOW

#define USE_CC1101_VIA_SPI
#define CC1101_GDO0_PIN 6
#define CC1101_GDO2_PIN 7
#define CC1101_SS_PIN 5
#define CC1101_MOSI_PIN SPI_MOSI_PIN
#define CC1101_SCK_PIN SPI_SCK_PIN
#define CC1101_MISO_PIN SPI_MISO_PIN

#define USE_NRF24_VIA_SPI
#define NRF24_CE_PIN 18
#define NRF24_SS_PIN 19
#define NRF24_MOSI_PIN SPI_MOSI_PIN
#define NRF24_SCK_PIN SPI_SCK_PIN
#define NRF24_MISO_PIN SPI_MISO_PIN

#define FP 1
#define FM 2
#define FG 3

#define HAS_SCREEN 1
#define ROTATION 1
#define MINBRIGHT (uint8_t)1

#define USER_SETUP_LOADED 1
#define ST7789_DRIVER 1
#define TFT_RGB_ORDER 0
#define TFT_WIDTH 170
#define TFT_HEIGHT 320
#define TFT_BACKLIGHT_ON 1
#define TFT_BL 14
#define TFT_RST 1
#define TFT_DC 11
#define TFT_MISO -1
#define TFT_MOSI 13
#define TFT_SCLK 12
#define TFT_CS 10
#define TOUCH_CS -1 // SDCARD_CS to make sure SDCard works
#define SMOOTH_FONT 1
#define SPI_FREQUENCY 40000000
#define SPI_READ_FREQUENCY 20000000

#define SDCARD_CS 21
#define SDCARD_SCK 17
#define SDCARD_MISO 16
#define SDCARD_MOSI 15

#define SPI_SCK_PIN 17
#define SPI_MOSI_PIN 15
#define SPI_MISO_PIN 16
#define SPI_SS_PIN 43

// RGB LED

#define HAS_RGB_LED 1
#define RGB_LED 45
#define LED_TYPE WS2812B
#define LED_ORDER GRB
#define LED_TYPE_IS_RGBW 0
#define LED_COUNT 16

#define USE_BQ25896

// === I2C Grove ===
#define GROVE_SDA SDA
#define GROVE_SCL SCL

// === IO EXPANDER (si on compte l'utiliser plus tard) ===
#define USE_IO_EXPANDER
#define IO_EXPANDER_AW9523
#define IO_EXP_GPS 20
#define IO_EXP_MIC 4
#define IO_EXP_VIBRO 2
#define IO_EXP_CC_RX 38
#define IO_EXP_CC_TX 39

#endif /* Pins_Arduino_h */
